#ifndef ALL_STRUCTURES_HH
#define ALL_STRUCTURES_HH

#include "bubblesort.h"
#include "heapsort.h"
#include "insertsort.h"
#include "introsort.h"
#include "mergesort.h"
#include "quicksort.h"
#include "shellsort.h"
#include "Heap.hh"

#endif