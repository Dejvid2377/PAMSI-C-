Dawid Krekora 254003

