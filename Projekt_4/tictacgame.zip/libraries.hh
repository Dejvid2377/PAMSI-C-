#ifndef _LIBRARIES_HH
#define _LIBRARIES_HH

#include <iostream>
#include <cstdlib>
#include <string>
#include <vector>
#include <cmath>
#include <ctime>
#include <sstream>
#include <unistd.h>
#include <chrono>
#include <fstream>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>

#endif