#include "graph.hpp"
#include "adjacency_list_graph.hpp"
#include "adjacency_matrix_graph.hpp"
#include "shortest_path_algorithms.hpp"
#include "libraries.hh"

using ShortestPathResult = std::map<int, std::pair<int, std::vector<int>>>;

int main ()
{   
  vector<int>  verticesAmount{10,50,100,150,200};
  vector<double>  graphDensity {0.25,0.5,0.75,1};
  double edgesAmount = 0;
  int startV, endV, edge;
  int begV;
  int total_exp =100;
  srand( time( NULL ) );
  double time {0};
  ofstream results1(EXP_RESULTS1); 
  ofstream results2(EXP_RESULTS2); 
  ofstream results3(EXP_RESULTS3); 
  ofstream results4(EXP_RESULTS4); 

//////////////////////////////////////////////////////////////////////////////////////////////////  
/*
  results1 << "Algorytm Dijkstry dla listy" <<endl;
  for (auto x : verticesAmount) {
    int & vAmnt = x;
    
    for(auto y: graphDensity) {
      double & graphDens = y;
    
      for(int i=0;i<total_exp;i++) 
      {
        AdjacencyListGraph<int> adj;
        edgesAmount = graphDens * vAmnt * (vAmnt-1);
        startV = rand() % vAmnt;
        adj.insertVertex(startV);
        auto ptr1 = adj.vertexID(startV);
        auto beg = ptr1;
        begV = startV;

        for (int j=0;j<edgesAmount;j++)
        {
            cout << "x: " <<vAmnt << " y: " << graphDens <<" i: "<<i<< " j: " << j << endl;
            endV = rand() % vAmnt;
            while (startV==endV)
              endV = rand() % vAmnt;
            edge = rand() % 100;
            
            auto ptr2 = adj.vertexID(endV);
            
            if (!ptr1)
            {
              adj.insertVertex(startV);
              ptr1 = adj.vertexID(startV);
            }
            if (!ptr2)
            {
              adj.insertVertex(endV);
              ptr2 = adj.vertexID(endV);
            }

            if(adj.areAdjacent(ptr1,ptr2))
                j--;
            else
                adj.insertEdge(ptr1,ptr2,edge);
            
            ptr1 = ptr2;
            startV = endV;
        }
        adj.set_startVertex(beg);
        ShortestPathResult result;

        auto start = std::chrono::system_clock::now();
        dijkstra(adj,begV,result);
        auto end = std::chrono::system_clock::now();
        std::chrono::duration<double> diff =
                end - start; // w sekundach https://en.cppreference.com/w/cpp/chrono/duration
        double durationTime = diff.count(); // zmierzony czas zapisa do pliku lub zagregowa, zapisa liczb badanych
                                        // elementów interesuje nas średnia wartość dla nbOfExperiments eksperymentów
        time+=durationTime;
      }
      cout << endl;
      time /= total_exp;
      results1 << "Ilosc wierzcholkow: " << vAmnt <<"| Gestosc: " << graphDens << endl;
      results1 << "*******************************" << endl;
      results1 <<"sredni czas: " << time << endl;
      results1 << "*******************************" << endl;
      time = 0;
    }
  }
*/
//////////////////////////////////////////////////////////////////////////////////////////////////  
/*
  results2 << "Algorytm Dijkstry dla macierzy" <<endl;
  for (auto x : verticesAmount) {
    int & vAmnt = x;
    
    for(auto y: graphDensity) {
      double & graphDens = y;
    
      for(int i=0;i<total_exp;i++) 
      {
        AdjacencyMatrixGraph<int> adj;
        edgesAmount = graphDens * vAmnt * (vAmnt-1);
        startV = rand() % vAmnt;
        adj.insertVertex(startV);
        auto ptr1 = adj.vertexID(startV);
        auto beg = ptr1;
        begV = startV;

        for (int j=0;j<edgesAmount;j++)
        {
            cout << "x: " <<vAmnt << " y: " << graphDens <<" i: "<<i<< " j: " << j << endl;
            endV = rand() % vAmnt;
            while (startV==endV)
              endV = rand() % vAmnt;
            edge = rand() % 100;
            
            auto ptr2 = adj.vertexID(endV);
            
            if (!ptr1)
            {
              adj.insertVertex(startV);
              ptr1 = adj.vertexID(startV);
            }
            if (!ptr2)
            {
              adj.insertVertex(endV);
              ptr2 = adj.vertexID(endV);
            }

            if(adj.areAdjacent(ptr1,ptr2))
                j--;
            else
                adj.insertEdge(ptr1,ptr2,edge);
            
            ptr1 = ptr2;
            startV = endV;
        }
        adj.set_startVertex(beg);
        ShortestPathResult result2;

        auto start = std::chrono::system_clock::now();
        dijkstra(adj,begV,result2);
        auto end = std::chrono::system_clock::now();
        std::chrono::duration<double> diff =
                end - start; // w sekundach https://en.cppreference.com/w/cpp/chrono/duration
        double durationTime = diff.count(); // zmierzony czas zapisa do pliku lub zagregowa, zapisa liczb badanych
                                        // elementów interesuje nas średnia wartość dla nbOfExperiments eksperymentów
        time+=durationTime;
      }
      cout << endl;
      time /= total_exp;
      results2 << "Ilosc wierzcholkow: " << vAmnt <<"| Gestosc: " << graphDens << endl;
      results2 << "*******************************" << endl;
      results2 <<"sredni czas: " << time << endl;
      results2 << "*******************************" << endl;
      time = 0;

    }
  }
*/
  //////////////////////////////////////////////////////////////////////////////////////////////////  
/*
  results3 << "Algorytm Bellmana-Forda dla listy " <<endl;
  for (auto x : verticesAmount) {
    int & vAmnt = x;
    
    for(auto y: graphDensity) {
      double & graphDens = y;
    
      for(int i=0;i<total_exp;i++) 
      {
        AdjacencyListGraph<int> adj;
        edgesAmount = graphDens * vAmnt * (vAmnt-1);
        startV = rand() % vAmnt;
        adj.insertVertex(startV);
        auto ptr1 = adj.vertexID(startV);
        auto beg = ptr1;
        begV = startV;

        for (int j=0;j<edgesAmount;j++)
        {
            cout << "x: " <<vAmnt << " y: " << graphDens <<" i: "<<i<< " j: " << j << endl;
            endV = rand() % vAmnt;
            while (startV==endV)
              endV = rand() % vAmnt;
            edge = rand() % 100;
            
            auto ptr2 = adj.vertexID(endV);
            
            if (!ptr1)
            {
              adj.insertVertex(startV);
              ptr1 = adj.vertexID(startV);
            }
            if (!ptr2)
            {
              adj.insertVertex(endV);
              ptr2 = adj.vertexID(endV);
            }

            if(adj.areAdjacent(ptr1,ptr2))
                j--;
            else
                adj.insertEdge(ptr1,ptr2,edge);
            
            ptr1 = ptr2;
            startV = endV;
        }
        adj.set_startVertex(beg);
        ShortestPathResult result3;

        auto start = std::chrono::system_clock::now();
        bool wynik = bellmanFord(adj,begV,result3);
        auto end = std::chrono::system_clock::now();
        std::chrono::duration<double> diff =
                end - start; // w sekundach https://en.cppreference.com/w/cpp/chrono/duration
        double durationTime = diff.count(); // zmierzony czas zapisa do pliku lub zagregowa, zapisa liczb badanych
                                        // elementów interesuje nas średnia wartość dla nbOfExperiments eksperymentów
        time+=durationTime;
      }
      cout << endl;
      time /= total_exp;
      results3 << "Ilosc wierzcholkow: " << vAmnt <<"| Gestosc: " << graphDens << endl;
      results3 << "*******************************" << endl;
      results3 <<"sredni czas: " << time << endl;
      results3 << "*******************************" << endl;
      time = 0;
    }
  }
  */
  //////////////////////////////////////////////////////////////////////////////////////////////////  
/*
  results4 << "Algorytm Bellmana-Forda dla macierzy " <<endl;
  for (auto x : verticesAmount) {
    int & vAmnt = x;
    
    for(auto y: graphDensity) {
      double & graphDens = y;
    
      for(int i=0;i<total_exp;i++) 
      {
        AdjacencyMatrixGraph<int> adj;
        edgesAmount = graphDens * vAmnt * (vAmnt-1);
        startV = rand() % vAmnt;
        adj.insertVertex(startV);
        auto ptr1 = adj.vertexID(startV);
        auto beg = ptr1;
        begV = startV;

        for (int j=0;j<edgesAmount;j++)
        {
            cout << "x: " <<vAmnt << " y: " << graphDens <<" i: "<<i<< " j: " << j << endl;
            endV = rand() % vAmnt;
            while (startV==endV)
              endV = rand() % vAmnt;
            edge = rand() % 100;
            
            auto ptr2 = adj.vertexID(endV);
            
            if (!ptr1)
            {
              adj.insertVertex(startV);
              ptr1 = adj.vertexID(startV);
            }
            if (!ptr2)
            {
              adj.insertVertex(endV);
              ptr2 = adj.vertexID(endV);
            }

            if(adj.areAdjacent(ptr1,ptr2))
                j--;
            else
                adj.insertEdge(ptr1,ptr2,edge);
            
            ptr1 = ptr2;
            startV = endV;
        }
        adj.set_startVertex(beg);
        ShortestPathResult result4;

        auto start = std::chrono::system_clock::now();
        bool wynik = bellmanFord(adj,begV,result4);
        auto end = std::chrono::system_clock::now();
        std::chrono::duration<double> diff =
                end - start; // w sekundach https://en.cppreference.com/w/cpp/chrono/duration
        double durationTime = diff.count(); // zmierzony czas zapisa do pliku lub zagregowa, zapisa liczb badanych
                                        // elementów interesuje nas średnia wartość dla nbOfExperiments eksperymentów
        time+=durationTime;
      }
      cout << endl;
      time /= total_exp;
      results4 << "Ilosc wierzcholkow: " << vAmnt <<"| Gestosc: " << graphDens << endl;
      results4 << "*******************************" << endl;
      results4 <<"sredni czas: " << time << endl;
      results4 << "*******************************" << endl;
      time = 0;
    }
  }
*/


    return 0;
}