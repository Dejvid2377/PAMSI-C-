#include <iostream>

int main(int argc, char* argv[])
{
    std::cout<< "Struktury danych"<<std::endl;
    return 0;
}