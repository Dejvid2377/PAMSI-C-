#ifndef LIBRARIES_HH
#define LIBRARIES_HH

#include <iostream>
#include <fstream>
using std::cout;
using std::cin;
using std::endl;
using std::size_t;
using std::ifstream;
using std::ofstream;

#define EXP_RESULTS "wyniki.ods"
#define EXP_RESULTS2 "wyniki.txt"

#endif