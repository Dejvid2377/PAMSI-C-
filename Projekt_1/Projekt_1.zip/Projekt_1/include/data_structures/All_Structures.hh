#ifndef ALL_STRUCTURES_HH
#define ALL_STRUCTURES_HH

#include "Heap.hh"
#include "StackTab.hh"
#include "StackList.hh"
#include "SinglyLinkedList.hh"
#include "DoublyLinkedList.hh"
#include "QueueTab.hh"
#include "QueueList.hh"

#endif